public class Task2 implements Runnable {

    @Override
    public void run() {
        System.out.println("this is Task 2");
        
    }


}
