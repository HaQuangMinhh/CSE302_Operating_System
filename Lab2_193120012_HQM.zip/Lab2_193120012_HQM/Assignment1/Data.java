public class Data {

    private int value = 0 ;

    public void increase() {
        this.value++;
    }
    public void decrease() {
        this.value--;
    }
    public int getValue() {
        return value;
    }

    public void setValue(int value) {
        this.value = value;
    } 
}
