public class PrintHelloThread extends Thread {
    
    public void run() {
        System.out.println( "Hello World" );
        
    }
}
