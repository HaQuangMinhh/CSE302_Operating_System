import java.util.ArrayList;
import java.util.List;

public class FCFS_Scheduler implements Scheduler {

    @Override
    public List<ScheduleInfor> schedule (List<Task> queue) {
    
        List<ScheduleInfor> results = new ArrayList<>(); 
        int currentTime = 0 ; 

        for ( Task task : queue ) {
            int duration = task.getBurst(); // Lấy time thực của mỗi tác vụ

            ScheduleInfor infor = new ScheduleInfor(currentTime, task, duration);
            results.add(infor);

            currentTime += duration ; // nguyên lý FCFS  : cập nhật time sau khi hoàn thành 1 tác vụ
        }        
        return results ; 
    }
}
