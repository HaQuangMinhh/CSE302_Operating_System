import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Main {

    public static final String Task_File = "schedule.txt";
    public static void main(String[] args) throws IOException {
        
        List<Task> queue = new ArrayList<>();
        BufferedReader reader = null ;

        System.out.println("--------------- First-come, first-served (FCFS)-------------------------- ");
        try {
            reader = new BufferedReader(new FileReader(Main.Task_File));

            String line ; 
            line = reader.readLine() ; 
            while ( line != null ) {
                String[] component = line.split(",");
                
                if ( component.length != 3 ) {
                    System.out.println("Invalid format...");
                    return ; 
                }

                String name = component[0].trim(); 
                int priority = Integer.parseInt(component[1].trim()) ;
                int burst = Integer.parseInt(component[2].trim());  

                Task task = new Task(name , priority, burst); 
                
                queue.add(task);
                line = reader.readLine(); 
                
            }
        } catch ( FileNotFoundException e1 ) {
            System.out.println("Error roi kia cha oi" + e1 );
        } catch ( IOException e2 ) {
            e2.printStackTrace();
        } finally {
            if ( reader != null )  {
                try {
                    reader.close();
                } catch ( IOException e ) {

                }
            }
        }

        for ( Task tasks : queue ) {
            System.out.println(tasks);
        }

        System.out.println(" ");

        Scheduler scheduler1 = new FCFS_Scheduler(); 

        List<ScheduleInfor> results1 = scheduler1.schedule(queue);

        for ( ScheduleInfor string : results1 ) {
            System.out.println(string);
        }


        System.out.println("---------------------Using Shortest-job-first (SJF)-------------------------");

        Scheduler scheduler = new SJF_Scheduler();

        List<ScheduleInfor> results = scheduler.schedule(queue);

        for (ScheduleInfor string : results) {
            System.out.println(string);
        }

        System.out.println("---------------------Using Priority Scheduling---------------------------");

        Scheduler scheduler2 = new Priority_Scheduler();

        List<ScheduleInfor> results2 = scheduler2.schedule(queue);
        
        for ( ScheduleInfor string : results2 ) {
            System.out.println(string);
        }

        System.out.println("---------------------Using Round-Robin------------------------------------------------");
    
        Scheduler scheduler3 = new RR_Scheduler(); 

        List<ScheduleInfor> results3 = scheduler3.schedule(queue);

        for ( ScheduleInfor string : results3 ) {
            System.out.println(string);
        }

        System.out.println("----------------------Using Priority Scheduling with Round Robin------------------------");

        Scheduler scheduler4 = new PrioritySchedulingWithRoundRobin() ; 

        List<ScheduleInfor> results4 = scheduler4.schedule(queue);

        for ( ScheduleInfor string : results4 ) {
            System.out.println(string);
        }

        
    }


}
