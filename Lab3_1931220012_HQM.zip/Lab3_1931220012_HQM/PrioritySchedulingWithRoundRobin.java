import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

public class PrioritySchedulingWithRoundRobin implements Scheduler {

    public static final int Time_QuanTum = 10 ;  // chưa hoàn thành theo on time thì sẽ đẩy vào cuối hàng đợi  

    public List<ScheduleInfor> schedule ( List<Task> queue ) {

        // Sắp xếp danh sách task theo độ ưu tiên (priority), tăng dần (lower value = higher priority)
        Collections.sort(queue , Comparator.comparing(Task::getPriority));

        List<ScheduleInfor> results = new ArrayList<>(); 
        int currentTime = 0 ; 
        Queue<Task> taskQueue = new LinkedList<>(); // Khởi tạo hàng đợi 

        // Lặp qua các task theo thứ tự ưu tiên
        for ( Task task : queue ) {
            taskQueue.offer(task);  // chuyển toàn độ danh sách sắp xếp vào hàng đợi 
        }

        // Xử lý task theo từng Round Robin   Chạy đến khi nào hk còn task nào 
        while ( ! taskQueue.isEmpty() )  {   // nếu cái hàng đợi trống 
            Task task = taskQueue.poll() ; // lấy task đầu tiên 
            int duration = task.getBurst() ;    // thời gian burst (thời gian cần để hoàn thành task)

            int timeToRun = Math.min(duration, Time_QuanTum); // nếu duration > time_Quantum thì sẽ dc thực thi hoàn toàn 

            // Save infor lịch trình 
            ScheduleInfor infor = new ScheduleInfor(currentTime, task, timeToRun);

            results.add(infor);

            currentTime += timeToRun ; 

            if ( duration > timeToRun ) {
                task.setBurst(duration - timeToRun);
                taskQueue.offer(task);
            }
        }
        return results ; 
    }

}
