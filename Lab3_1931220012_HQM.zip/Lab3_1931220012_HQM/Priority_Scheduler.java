import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class Priority_Scheduler implements Scheduler {


    public List<ScheduleInfor> schedule ( List<Task> queue ) {

        // Sắp xếp danh sách task theo độ ưu tiên (priority), tăng dần (lower value = higher priority)
        Collections.sort(queue , Comparator.comparing(Task::getPriority) );

        List<ScheduleInfor> results = new ArrayList<>();
        int currentTime = 0 ; 

        for ( Task task : queue ) {
            int duration = task.getBurst() ; 

            ScheduleInfor infor = new ScheduleInfor(currentTime, task , duration);
            results.add(infor);

            currentTime += duration ; 
        }
        
        return results; 
    }
}
