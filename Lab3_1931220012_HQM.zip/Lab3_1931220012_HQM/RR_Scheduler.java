
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

public class RR_Scheduler implements Scheduler {

    public static final int Time_QuanTum = 10 ;  // chưa hoàn thành theo on time thì sẽ đẩy vào cuối hàng đợi  

    @Override
    public List<ScheduleInfor> schedule(List<Task> queue) {
        
        List<ScheduleInfor> results = new ArrayList<>() ; 

        int currentTime = 0 ; 

        Queue<Task> taskQueue = new LinkedList<>(queue);

        while ( ! taskQueue.isEmpty() ) {   // lặp cho đến khi rỗng 
            Task task = taskQueue.poll(); 
            int duration = task.getBurst();

            int timeRun = Math.min(duration, Time_QuanTum); // Tính thời gian thực thi. 
            // Nếu TimeRun > Time_QuanTum --> chỉ chạy trong 10s

            ScheduleInfor infor = new ScheduleInfor(currentTime, task , timeRun); 
            results.add(infor);

            currentTime += timeRun ; 

            // Xử lý tác vụ chưa hoàn thành 
            if ( duration > Time_QuanTum ) {
                task.setBurst(duration - timeRun); //Cập nhật thời gian thực thi còn lại
                taskQueue.offer(task);  // Đưa tác vụ quay lại hàng đợi
            }
        }
        return results ;
    }


}
