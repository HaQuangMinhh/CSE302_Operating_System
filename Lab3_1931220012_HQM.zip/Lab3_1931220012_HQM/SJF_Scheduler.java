
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class SJF_Scheduler implements Scheduler {

    @Override
    public List<ScheduleInfor> schedule(List<Task> queue) {
        
        // Sắp xếp danh sách task theo burst time tăng dần
        Collections.sort(queue, Comparator.comparingInt(Task::getBurst) ); // Xử lý các tác vụ nhỏ trước 
        
        List<ScheduleInfor> results = new ArrayList<>(); 
        int currentTime = 0 ; 

        for ( Task task : queue ) {
            int duration = task.getBurst(); 

            ScheduleInfor infor = new ScheduleInfor(currentTime, task, duration);
            results.add(infor);

            currentTime += duration ; 
        }
        return results ; 
        
    }


}
