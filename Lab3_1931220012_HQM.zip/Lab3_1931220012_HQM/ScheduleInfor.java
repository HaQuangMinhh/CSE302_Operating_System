public class ScheduleInfor {

    private int time ; 
    private Task task ; 
    private int duration ;
    
    public ScheduleInfor(int time, Task task, int duration) {
        this.time = time;
        this.task = task;
        this.duration = duration;
    }

    public int getTime() {
        return time;
    }

    @Override
    public String toString() {
        return "ScheduleInfor [time= " + time + ", task= " + task + ", duration= " + duration + "]";
    }

    public Task getTask() {
        return task;
    }

    public int getDuration() {
        return duration;
    } 
}
