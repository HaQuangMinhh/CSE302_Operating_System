import java.util.List;

public interface Scheduler {
    public List<ScheduleInfor> schedule (List<Task> queue) ; // return chuỗi String
}
