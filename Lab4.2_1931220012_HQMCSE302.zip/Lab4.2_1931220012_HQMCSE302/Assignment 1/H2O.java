public class H2O {


    public H2O () {

    }

    public void hydrogen() {


    }

    public void oxygen() {

        
    }
}
