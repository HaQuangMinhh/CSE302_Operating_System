public class Main {


    public static void main(String[] args) {
        
        MyThreadPool tp = new MyThreadPool(5); 

        for ( int i = 0 ; i < 100 ; i++ ) {
            Runnable task1 = new Runnable() {

                @Override
                public void run() {
                    System.out.println("This is Task 1");
                }
            }; 
    
            tp.add(task1);
        }

        Runnable task2 = new Runnable() {

            @Override
            public void run() {
                int x = 7 ; 
                int y = 8 ; 
                System.out.println("This is Task 2, x +y = " + ( x + y ));
            }
        }; 
        tp.add(task2);


        tp.shutdown();

    }


}
