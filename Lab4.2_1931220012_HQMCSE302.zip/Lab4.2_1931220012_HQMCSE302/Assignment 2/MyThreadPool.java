import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class MyThreadPool {
    private int size;
    private List<Thread> threads = new ArrayList<>();
    private LinkedList<Runnable> tasks = new LinkedList<>();
    private Lock lock = new ReentrantLock();
    private Condition condition = this.lock.newCondition();

    public MyThreadPool() {
        this(3);
    }

    public MyThreadPool(int size) {
        this.size = size;

        for (int i = 0; i < this.size; i++) {
            Thread t = new Thread(new Runnable() {

                @Override
                public void run() {
                    Runnable task;
                    while (true) {
                        task = null;
                        MyThreadPool.this.lock.lock();
                        try {
                            if (MyThreadPool.this.tasks.isEmpty()) {
                                MyThreadPool.this.condition.await();
                            } else {
                                task = MyThreadPool.this.tasks.getFirst();
                            }
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        } finally {
                            MyThreadPool.this.lock.unlock();
                        }
                        if (task != null) {
                            task.run();
                        }
                    }
                }

            });
            threads.add(t);
            t.start();
        }
    }

    public void add(Runnable task) {
        this.lock.lock();
        try {
            this.tasks.add(task);
            this.condition.signal();
        } finally {
            this.lock.unlock();
        }
    }

    public void shutdown() {

    }
    
}
