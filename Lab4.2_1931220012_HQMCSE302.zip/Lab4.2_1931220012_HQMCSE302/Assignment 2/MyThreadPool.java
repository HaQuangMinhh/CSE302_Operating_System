import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.locks.ReentrantLock;

public class MyThreadPool {


    private int size ; 
    private List<Thread> threads = new ArrayList<>(); 

    private LinkedList<Runnable> tasks = new LinkedList<>(); 
    private ReentrantLock lock = new ReentrantLock(); 

    public MyThreadPool () {
        this(3);
    }

    public MyThreadPool ( int size ) {
        this.size = size ;
        
        for ( int i = 0 ; i < this.size ; i++ ) {
            Thread t = new Thread(new Runnable() {
                @Override
                public void run() {
                    // ???
                    
                }
            });
            this.threads.add(t);
            t.start();

        }
    }

    public void add ( Runnable task  ) {
        this.lock.lock(); 

        try {
            this.tasks.add(task);
        } finally {
            this.lock.unlock();
        }

        this.tasks.add(task);
    }

    public void shutdown() {


    }
}
