import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class FirstReaderWriters {

    // Số lượng người đọc hiện tại
    private int readerCount = 0;

    // Count writer
    private int writerCount = 0 ; 

    // Khóa (Lock) để bảo vệ truy cập vào readerCount
    private Lock lock = new ReentrantLock();

    // Điều kiện để điều khiển chờ giữa các reader và writer
    private Condition readCondition = this.lock.newCondition();
    private Condition writeCondition = this.lock.newCondition();


    public FirstReaderWriters() {
    }

    public void readEnter() throws InterruptedException {
        this.lock.lock();

        try {
            if ( this.writerCount > 0 ) {
                this.readCondition.await();
            }
            this.readerCount++;

        } finally {
            this.lock.unlock();
        }

    }

    public void readExit() {
        this.lock.lock();

        try {
            // Giảm số lượng reader
            this.readerCount--;

            // Nếu là reader cuối cùng, cho phép writer có thể vào
            if (this.readerCount == 0) {
                // Thông báo cho writer rằng nó có thể vào
                writeCondition.signal();
            }

        } finally {
            this.lock.unlock();
        }

    }

    public void writeEnter() throws InterruptedException {
        this.lock.lock();

        try {

             // Nếu có reader đang đọc hoặc có writer đang viết, writer phải đợi
            if ( this.readerCount > 0 || this.writerCount > 0 ) {
                this.writeCondition.await();
            }
            this.writerCount++;

        } finally {
            this.lock.unlock();
        }

    }

    public void writeExit() throws InterruptedException {
        this.lock.lock();

        try {
            // Giảm số lượng writer
            this.writerCount--;

            // Sau khi writer kết thúc, cho phép reader vào
            readCondition.signalAll(); // Thông báo cho tất cả các reader đang chờ

            // Thông báo cho writer tiếp theo (nếu có)
            writeCondition.signal();
            
        } finally {
            this.lock.unlock();
        }

    }

}
