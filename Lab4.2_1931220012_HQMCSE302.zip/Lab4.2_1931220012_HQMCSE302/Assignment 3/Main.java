import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Main {


    public static void main(String[] args) throws InterruptedException {
        
        FirstReaderWriters rw = new FirstReaderWriters();

        List<Thread> readThreads = new ArrayList<>(); 
        for ( int i = 0 ; i < 10 ; i++ ) {
            Thread t = new ReadThread(rw);
            readThreads.add(t);

            t.start();
        }

        List<Thread> writeThreads = new ArrayList<>();
        for ( int i = 0 ; i < 5 ; i++ ) {
            Thread t = new WriteThread(rw);
            writeThreads.add(t);

            t.start();

        }

        // 
        Thread.sleep(5000);
        
        for ( Thread t : readThreads  ) {
            ( ( ReadThread )t ).shutdown();
        }

        for ( Thread t : readThreads  ) {
            ( ( WriteThread )t ).shutdown();
        }

    }

}

class ReadThread extends Thread {

    private FirstReaderWriters rw ; 
    private boolean running = true  ; 

    public ReadThread ( FirstReaderWriters rw ) {
        this.rw = rw ; 
    }

    @Override
    public void run() {

        Random rd = new Random();

        try {
            while ( this.running == true  ) {
                this.rw.readEnter();
    
                System.out.println("I am reading...");
    
                
                Thread.sleep(rd.nextInt(100));
                
    
                System.out.println("Done");
                // Reading : finished

                // Reading
                this.rw.readExit();
    
                // outside......
                
                Thread.sleep(rd.nextInt(50));
                
            }
        } catch ( InterruptedException e ) {
        }
        
    }

    public void shutdown() {
        this.interrupt();

        this.running = false ; 
    }

}


// -----------------------------------------------------------------------------Write
class WriteThread extends Thread {

    private FirstReaderWriters rw ; 
    private boolean running = true  ; 

    public WriteThread ( FirstReaderWriters rw ) {
        this.rw = rw ; 
    }

    @Override
    public void run() {

        Random rd = new Random();

        try {
            while ( this.running == true  ) {
                this.rw.writeEnter();
    
                System.out.println("I am Writing......");
    
                
                Thread.sleep(rd.nextInt(100));
                
    
                System.out.println("Done");
                // Reading : finished

                // Reading
                this.rw.writeExit();
    
                // outside......
                
                Thread.sleep(rd.nextInt(50));
                
            }
        } catch ( InterruptedException e ) {
        }
        
    }

    public void shutdown() {
        this.interrupt();

        this.running = false ; 
    }

}
