import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Main {

    public static void main(String[] args) throws InterruptedException {
        // Tạo đối tượng SecondReaderWriters để đồng bộ hóa giữa readers và writers
        SecondReaderWriters rw = new SecondReaderWriters();

        // Danh sách các thread đọc
        List<Thread> readThreads = new ArrayList<>();
        for (int i = 0; i < 10; i++) {
            Thread t = new ReadThread(rw);
            readThreads.add(t);
            t.start();
        }

        // Danh sách các thread ghi
        List<Thread> writeThreads = new ArrayList<>();
        for (int i = 0; i < 5; i++) {
            Thread t = new WriteThread(rw);
            writeThreads.add(t);
            t.start();
        }

        // Chờ một chút để các threads thực hiện công việc
        Thread.sleep(5000);

        // In ra số lượng writers đang chờ
        System.out.println("Number of writers waiting: " + rw.getWaitingWriters());

        // Dừng các thread đọc
        for (Thread t : readThreads) {
            ((ReadThread) t).shutdown();
        }

        // Dừng các thread ghi
        for (Thread t : writeThreads) {
            ((WriteThread) t).shutdown();
        }

        // Chờ các threads kết thúc
        for (Thread t : readThreads) {
            t.join();
        }

        for (Thread t : writeThreads) {
            t.join();
        }
    
    
    }    
}

class ReadThread extends Thread {

    private SecondReaderWriters rw;
    private boolean running = true;

    public ReadThread(SecondReaderWriters rw) {
        this.rw = rw;
    }

    @Override
    public void run() {
        Random rd = new Random();

        try {
            while (running) {
                rw.readEnter();
                
                System.out.println(Thread.currentThread().getName() + " is reading...");

                Thread.sleep(rd.nextInt(100));  // Giả lập công việc đọc

                System.out.println(Thread.currentThread().getName() + " finished reading.");
                
                rw.readExit();

                Thread.sleep(rd.nextInt(50));  // Giả lập thời gian nghỉ ngơi
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    public void shutdown() {
        this.running = false;
        this.interrupt();
    }
}

class WriteThread extends Thread {

    private SecondReaderWriters rw;
    private boolean running = true;

    public WriteThread(SecondReaderWriters rw) {
        this.rw = rw;
    }

    @Override
    public void run() {
        Random rd = new Random();

        try {
            while (running) {
                rw.writeEnter();
                System.out.println(Thread.currentThread().getName() + " is writing...");
                Thread.sleep(rd.nextInt(100));  // Giả lập công việc ghi
                System.out.println(Thread.currentThread().getName() + " finished writing.");
                rw.writeExit();
                Thread.sleep(rd.nextInt(50));  // Giả lập thời gian nghỉ ngơi
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    public void shutdown() {
        this.running = false;
        this.interrupt();
    }
}