import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class SecondReaderWriters {

    // Số lượng người đọc hiện tại
    private int readerCount = 0;

    // Số lượng writer đang viết
    private int writerCount = 0;

    // Số lượng writer đang chờ đợi
    private int waitingWriters = 0;

    // Khóa (Lock) để bảo vệ truy cập vào readerCount và writerCount
    private Lock lock = new ReentrantLock();

    // Điều kiện để điều khiển chờ giữa các reader và writer
    private Condition readCondition = this.lock.newCondition();
    private Condition writeCondition = this.lock.newCondition();

    public SecondReaderWriters() {
    }

    // Phương thức khi một reader muốn vào
    public void readEnter() throws InterruptedException {
        this.lock.lock();

        try {
            // Nếu có writer đang đợi, reader phải đợi
            while (this.writerCount > 0 || this.waitingWriters > 0) {
                this.readCondition.await();
            }

            // Tăng số lượng reader
            this.readerCount++;

        } finally {
            this.lock.unlock();
        }
    }

    // Phương thức khi một reader kết thúc đọc
    public void readExit() {
        this.lock.lock();

        try {
            // Giảm số lượng reader
            this.readerCount--;

            // Nếu là reader cuối cùng, cho phép writer có thể vào
            if (this.readerCount == 0) {
                writeCondition.signal();
            }

        } finally {
            this.lock.unlock();
        }
    }

    // Phương thức khi một writer muốn vào
    public void writeEnter() throws InterruptedException {
        this.lock.lock();

        try {
            // Writer phải đợi nếu có reader đang đọc hoặc có writer đang viết
            
            while (this.readerCount > 0 || this.writerCount > 0 ) {
                waitingWriters++;  // Tăng số lượng writer đang chờ đợi
                this.writeCondition.await();
                waitingWriters--;
            }

            // Writer đã có thể vào, giảm số lượng writer đang chờ
            this.writerCount++;

        } finally {
            this.lock.unlock();
        }
    }

    // Phương thức khi một writer kết thúc viết
    public void writeExit() {
        this.lock.lock();

        try {
            // Giảm số lượng writer
            this.writerCount--;

            // Thông báo cho reader và writer tiếp theo có thể vào
            readCondition.signalAll();  // Thông báo cho tất cả các reader
            writeCondition.signal();    // Thông báo cho writer tiếp theo

        } finally {
            this.lock.unlock();
        }
    }

    // Phương thức để lấy số lượng writer đang chờ
    public int getWaitingWriters() {
        this.lock.lock();
        try {
            return this.waitingWriters;
        } finally {
            this.lock.unlock();
        }
    }
}
