import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.random.*;

public class Main {


    public static void main(String[] args) throws InterruptedException {
        OldBridge ob = new OldBridge();
        Random rd = new Random(); 
        List<Thread> threads = new ArrayList<>(); 

        for ( int i = 0 ; i < 10 ; i++ ) {   // 10 chiếc xe
            Thread t = new Thread(new Runnable() {

                @Override
                public void run() {
                    try {
                        int dir = rd.nextInt(); 

                        ob.arrive(dir % 2); // vượt qua arrive là lên cầu 

                        // on the bridge 
                        Thread.sleep(10);
                        ob.exit(dir % 2) ; 

                    } catch (InterruptedException e) {
                        
                        e.printStackTrace();
                    }
                }
                
            });
            threads.add(t);
            t.start();
            
        }

        for ( Thread t : threads ) {
            t.join();
        }


    }

}
