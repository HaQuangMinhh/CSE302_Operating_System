import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class DiningPhilosophers1 {
    private final static int N = 5;
    private ReentrantLock[] forks;

    public DiningPhilosophers1() {
        this.forks = new ReentrantLock[N];

        for (int i = 0; i < N; i++) {
            this.forks[i] = new ReentrantLock(); 
        }

    }

    public void getForks(int id) {
        if ( id % 2 == 0 ) {
            this.forks[id].lock() ; // Get right fork 
            forks[(id + 1) % N].lock();      // Get the left fork
        } else {
            forks[(id + 1) % N].lock();                        // Get the left fork 
            forks[id].lock();                        // Get the right fork 

        }
    }

    public void releaseForks(int id) {
        // release two forks
        forks[id].unlock();
        forks[(id + 1) % N].unlock();

    }

}
