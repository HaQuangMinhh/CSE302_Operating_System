import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class DiningPhilosopher2 {

    private static final int N = 5 ; 
    private int remainForks = N ; 
    private int eatingCount = 0 ; 

    private Lock lock = new ReentrantLock(); 
    private Condition cond = this.lock.newCondition() ; 

    public DiningPhilosopher2 () {

    }

    public void getFork( ) {   // không quan tam đến có bao nhiu ng philosopher , quan tâm đến số người 
        lock.lock();
        // get the first fork 
        
        // if ( this.remainForks > 1 || this.remainForks == 1 && this.eatingCount > 0 ) {
        //     cond.await();
        // }

        try {
            // Chờ đến khi có đủ 2 nĩa để ăn
            while (remainForks < 2) {
                cond.await();
            }

            // Lấy 2 nĩa
            remainForks -= 2;
            eatingCount++;

        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        } finally {
            lock.unlock();
        }


        // get the second  fork 


    }

    public void releaseForks () {
        this.lock.lock();

        try {
            this.remainForks += 2 ; 
            this.eatingCount-- ; 

            this.cond.signalAll();   // gửi tin hieu len chay lại

        } finally {
            this.lock.unlock();
        }


    }

}
