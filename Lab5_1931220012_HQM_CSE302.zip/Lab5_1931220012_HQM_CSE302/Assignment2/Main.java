import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Main {

    public static void main(String[] args) throws InterruptedException {
        // muốn ăn phải đủ 2 cái nỉa
        DiningPhilosopher2 dp2 = new DiningPhilosopher2();

        List<Philosopher> list = new ArrayList<>(); 
        for ( int i = 0 ; i < 5 ; i++ ) {
            Philosopher p = new Philosopher(dp2);
            p.setName("Philosopher " + i);

            p.start();
            list.add(p);
        } 

        Thread.sleep(1000);
        
        for ( Philosopher p : list ) {
            p.shutdown() ; 
        }

    }

}

class Philosopher extends Thread {
    private DiningPhilosopher2 dp2;
    private boolean running  = true ; 

    public Philosopher(DiningPhilosopher2 dp2) {
        this.dp2 = dp2;
    }

    @Override
    public void run() {

        Random rd = new Random(); 
        while  ( true ) {

            // thinking
            System.out.println(Thread.currentThread().getName() + " is thinking...");

            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                
                e.printStackTrace();
            }

            // get forks 
            System.out.println(Thread.currentThread().getName() + " is trying to pick up forks.");
            this.dp2.getFork();

            // eating
            System.out.println(Thread.currentThread().getName() + " is eating...");
            try {
                Thread.sleep(  rd.nextInt(50)  );
            } catch ( InterruptedException e ) {
            }

            // release forks 
            this.dp2.releaseForks();
            System.out.println(Thread.currentThread().getName() + " put down forks.");
        }
    
    }

    public void shutdown () {
        running = false;
        this.interrupt(); // Đánh thức nếu đang bị sleep()
    }

}
