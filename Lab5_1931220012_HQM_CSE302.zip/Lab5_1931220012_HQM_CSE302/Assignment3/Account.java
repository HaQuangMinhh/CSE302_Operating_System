import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class Account {

private int balance;
    private final Lock lock = new ReentrantLock();

    public Account(int balance) {
        this.balance = balance;
    }

    public int getBalance() {
        return balance;
    }

    public void withdraw(int amount) {
        balance -= amount;
    }

    public void deposit(int amount) {
        balance += amount;
    }

    public Lock getLock() {
        return lock;
    }


}

class Transaction {
    public static void transfer(Account acc1, Account acc2, int amount) {
        Account first = (System.identityHashCode(acc1) < System.identityHashCode(acc2)) ? acc1 : acc2;
        Account second = (first == acc1) ? acc2 : acc1;

        first.getLock().lock();
        try {
            second.getLock().lock();
            try {
                if (acc1.getBalance() >= amount) {
                    acc1.withdraw(amount);
                    acc2.deposit(amount);
                    System.out.println("Transferred " + amount + " from Account " + acc1.hashCode() + " to Account " + acc2.hashCode());
                } else {
                    System.out.println("Not enough balance in Account " + acc1.hashCode());
                }
            } finally {
                second.getLock().unlock();
            }
        } finally {
            first.getLock().unlock();
        }
    }
}
