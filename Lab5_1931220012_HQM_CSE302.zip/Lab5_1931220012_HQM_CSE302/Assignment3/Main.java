public class Main {


    public static void main(String[] args) {
    
        Account acc1 = new Account(1000);
        Account acc2 = new Account(1000);

        Thread t1 = new Thread(() -> Transaction.transfer(acc1, acc2, 100));
        Thread t2 = new Thread(() -> Transaction.transfer(acc2, acc1, 200));

        t1.start();
        t2.start();

    }

}
