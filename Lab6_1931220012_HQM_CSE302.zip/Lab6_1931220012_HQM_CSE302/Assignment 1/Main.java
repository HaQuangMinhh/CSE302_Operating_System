import java.util.Scanner;

public class Main {


    public static void main(String[] args) {
        
        // Tính số page + offSet
        
        // Đề cung cấp : 32 bit ảo 
        // 4 KB

        // page size = 4 KB = 4096 byte   
        final int PAGESIZE = 4096 ; // 1 KB = 1024

        Scanner sc = new Scanner(System.in); 
        System.out.println("Input virtual address");
        int virtualAddress = sc.nextInt(); 

        // Calculate page size and offset
        int pageNumber = virtualAddress / PAGESIZE ; // 19986 / 4096
        int offSet = virtualAddress % PAGESIZE ;    // 19986 mod 4096

        // Out
        System.out.println("The address " + virtualAddress + " contains:");
        System.out.println("Page number = " + pageNumber);
        System.out.println("Offset = " + offSet);

        sc.close();
    }

    
}
