public class Block {


    private String name ; 
    private int address ; 
    private int size ;
    
    public Block(String name, int address, int size) {
        this.name = name;
        this.address = address;
        this.size = size;
    }

    



    // Getter and Setter
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAddress() {
        return address;
    }

    public void setAddress(int address) {
        this.address = address;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    } 

    
}
