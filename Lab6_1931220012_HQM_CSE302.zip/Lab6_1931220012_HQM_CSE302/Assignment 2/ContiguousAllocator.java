import java.util.ArrayList;
import java.util.List;

public class ContiguousAllocator {

    private List<Block> list = new ArrayList<>();

    private int memorySize; // total memory size

    public ContiguousAllocator(int memorySize) {
        this.memorySize = memorySize;

        this.list = new ArrayList<>();

        Block b = new Block(null, 0, this.memorySize);
        this.list.add(b);
    }

    public void changeSize(int newSize) {
        this.memorySize = newSize;

        this.list.clear();

        Block b = new Block(null, 0, this.memorySize);
        this.list.add(b);
    }

    public boolean requestFirstFit(String name, int size) {
        for (int i = 0; i < list.size(); i++) {
            Block b = list.get(i);

            // Nếu là vùng trống và đủ kích thước
            if (b.getName() == null && b.getSize() >= size) {
                int remainingSize = b.getSize() - size;

                // Nếu lỗ hổng có kích thước đúng bằng yêu cầu
                if (remainingSize == 0) {
                    b.setName(name);
                } else {
                    // Tạo một vùng mới với kích thước còn lại
                    Block allocatedBlock = new Block(name, b.getAddress(), size);
                    Block newFreeBlock = new Block(null, b.getAddress() + size, remainingSize);

                    // Thay thế vùng trống cũ bằng vùng mới và thêm vùng trống còn lại vào danh sách
                    list.set(i, allocatedBlock);
                    list.add(i + 1, newFreeBlock);
                }
                return true;
            }
        }
        return false; // Không tìm thấy vùng trống phù hợp
    }

    public boolean requestBestFit(String name, int size) {
        int bestIndex = -1;
        int bestSize = Integer.MAX_VALUE;

        // Tìm lỗ hổng nhỏ nhất đủ lớn
        for (int i = 0; i < list.size(); i++) {
            Block b = list.get(i);
            if (b.getName() == null && b.getSize() >= size && b.getSize() < bestSize) {
                bestIndex = i;
                bestSize = b.getSize();
            }
        }

        // Nếu không tìm thấy lỗ hổng phù hợp
        if (bestIndex == -1)
            return false;

        Block bestBlock = list.get(bestIndex);
        int remainingSize = bestBlock.getSize() - size;

        if (remainingSize == 0) {
            bestBlock.setName(name);
        } else {
            Block allocatedBlock = new Block(name, bestBlock.getAddress(), size);
            Block newFreeBlock = new Block(null, bestBlock.getAddress() + size, remainingSize);
            list.set(bestIndex, allocatedBlock);
            list.add(bestIndex + 1, newFreeBlock);
        }

        return true;
    }

    public boolean requestWorstFit(String name, int size) {
        int worstIndex = -1;
        int worstSize = -1;

        // Tìm lỗ hổng lớn nhất đủ lớn
        for (int i = 0; i < list.size(); i++) {
            Block b = list.get(i);
            if (b.getName() == null && b.getSize() >= size && b.getSize() > worstSize) {
                worstIndex = i;
                worstSize = b.getSize();
            }
        }

        // Nếu không tìm thấy lỗ hổng phù hợp
        if (worstIndex == -1)
            return false;

        Block worstBlock = list.get(worstIndex);
        int remainingSize = worstBlock.getSize() - size;

        if (remainingSize == 0) {
            worstBlock.setName(name);
        } else {
            Block allocatedBlock = new Block(name, worstBlock.getAddress(), size);
            Block newFreeBlock = new Block(null, worstBlock.getAddress() + size, remainingSize);
            list.set(worstIndex, allocatedBlock);
            list.add(worstIndex + 1, newFreeBlock);
        }

        return true;
    }

    public boolean release(String name) {
        for (int i = 0; i < list.size(); i++) {
            Block b = list.get(i);
            if (name.equals(b.getName())) {
                b.setName(null);
                // Merge with adjacent free blocks
                mergeHoles(i);
                return true;
            }
        }
        return false;
    }

    private void mergeHoles(int index) {
        // Merge with next block if it's free
        while (index < list.size() - 1 && list.get(index).getName() == null && 
               list.get(index + 1).getName() == null) {
            Block current = list.get(index);
            Block next = list.get(index + 1);
            current.setSize(current.getSize() + next.getSize());
            list.remove(index + 1);
        }
        
        // Merge with previous block if it's free
        while (index > 0 && list.get(index).getName() == null && 
               list.get(index - 1).getName() == null) {
            Block prev = list.get(index - 1);
            Block current = list.get(index);
            prev.setSize(prev.getSize() + current.getSize());
            list.remove(index);
            index--;
        }
    }


    public boolean releaseMemory(String name) {
        boolean found = false;
    
        for (Block b : list) {
            if (name.equals(b.getName())) {
                b.setName(null);  // Đánh dấu là lỗ hổng
                found = true;
            }
        }
    
        if (found) compactMemory();  // Gộp lỗ hổng lại nếu có thể
        return found;
    }

    public void compactMemory() {
        for (int i = 0; i < list.size() - 1; i++) {
            Block current = list.get(i);
            Block next = list.get(i + 1);
    
            if (current.getName() == null && next.getName() == null) {
                current.setSize(current.getSize() + next.getSize());
                list.remove(i + 1);
                i--;  // Kiểm tra lại vị trí này sau khi gộp
            }
        }
    }

    public String stat() {
        String result = "";

        for (Block b : this.list) {
            result += "Address: [" + b.getAddress() + ":" + (b.getAddress() + b.getSize() - 1) + "]";

            if (b.getName() != null) {
                result += " Process " + b.getName();
            } else {
                result += " Unused";
            }
        }

        return result;
    }

}
