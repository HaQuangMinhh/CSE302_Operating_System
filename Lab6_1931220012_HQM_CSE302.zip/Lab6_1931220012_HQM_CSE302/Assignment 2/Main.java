import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        ContiguousAllocator cma = new ContiguousAllocator(4096);

        Scanner keyboard = new Scanner(System.in);

        while (true) {

            System.out.println("Allocator>");
            String cmdLine = keyboard.nextLine();

            cmdLine = cmdLine.trim();
            cmdLine = cmdLine.toUpperCase();

            if (cmdLine.equals("Q")) {
                break;
            }

            String[] components = cmdLine.split("\\s+");

            switch (components[0]) {
                case "STAT":
                    if (components.length != 1) {
                        System.out.println(" The number of components is incorrect.");
                        continue;
                    }

                    String stat = cma.stat(); // Hiển thị trạng thái bộ nhớ
                    System.out.println(stat);
                    break;

                case "RQ":
                    if (components.length != 4) {
                        System.out.println(" The number of components is incorrect.");
                        continue;
                    }

                    String name = components[1];
                    
                    int size = Integer.parseInt(components[2]);
                    
                    String method = components[3];
                    
                    boolean result;

                    // Xử lý yêu cầu cấp phát bộ nhớ theo chiến lược
                    switch (method) {
                        case "F":
                            result = cma.requestFirstFit(name, size);
                            break;
                        case "B":
                            result = cma.requestBestFit(name, size);
                            break;
                        case "W":
                            result = cma.requestWorstFit(name, size);
                            break;
                        default:
                            System.out.println("Invalid allocation method.");
                            continue;
                    }

                    if (! result) {
                        System.out.println("Cannot allocate the block...");
                    }
                    break;

                case "RL":
                    if (components.length != 2) {
                        System.out.println("Invalid command");
                        continue;
                    }
                    String processName = components[1];
                    cma.release(processName); // Giải phóng bộ nhớ của tiến trình
                    break;

                case "C":
                    if (components.length != 1) {
                        System.out.println("Invalid command");
                        continue;
                    }
                    cma.compactMemory(); // Nén bộ nhớ
                    break;

                default:
                System.out.println("The number of components is incorrect.");
                    break;
            }

            // if (components[0].equals("stat")) {
            //     if (components.length != 1) {
            //         System.out.println("Invalid command");
            //         continue;
            //     }
            //     cma.stat();
            // }

            // if (components[0].equals("RQ")) { // request

            //     if (components.length != 4) {
            //         System.out.println("Invalid command");
            //         continue;
            //     }

            //     String name = components[1];
            //     int size = Integer.parseInt(components[2]);

            //     String method = components[3];
            //     boolean result;

            //     if (method.equals("F")) { // firt fit
            //         result = cma.requestFirstFit(name, size);
            //     } else if (method.equals("B")) {
            //         result = cma.requestBestFit(name, size);
            //     } else {
            //         result = cma.requestWorstFit(name, size);
            //     }
            //     if (result == false) {
            //         System.out.println("cannot allocate the block ...");
            //     }

            // }

        }

        keyboard.close();
    }
}
