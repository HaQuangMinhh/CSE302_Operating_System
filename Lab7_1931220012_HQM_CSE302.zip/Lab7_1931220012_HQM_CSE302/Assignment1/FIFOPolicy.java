
import java.util.LinkedList;

public class FIFOPolicy implements PageReplacementPolicy {

    private int frameNum;
    private LinkedList<Integer> frames;

    public FIFOPolicy(int frameNum) {
        this.frameNum = frameNum;
        this.frames = new LinkedList<>();
    }

    @Override
    public Result refer(int page) {
        if (frames.contains(page)) {
            return new Result(false, frames.indexOf(page), -1);
        }

        if (frames.size() < frameNum) {
            frames.add(page);
            return new Result(true, frames.size() - 1, -1);
        } else {
            int replacedPage = frames.removeFirst();
            int frame = frames.size(); // Vị trí cuối cùng sau khi thêm
            frames.add(page);
            return new Result(true, frame, replacedPage);
        }
    }

}
