
import java.util.LinkedList;

public class LRUPolicy implements PageReplacementPolicy {

    private int frameNum;
    private LinkedList<Integer> frames;

    public LRUPolicy(int frameNum) {
        this.frameNum = frameNum;
        this.frames = new LinkedList<>();
    }

    @Override
    public Result refer(int page) {
        int frame = frames.indexOf(page);
        if (frame >= 0) {
            frames.remove(frame); // Xóa trang đã truy cập
            frames.addLast(page); // Đưa lên cuối (gần đây nhất)
            return new Result(false, frame, -1);
        }

        if (frames.size() < frameNum) {
            frames.add(page);
            return new Result(true, frames.size() - 1, -1);
        } else {
            int replacedPage = frames.removeFirst(); // Xóa trang ít dùng nhất
            frame = frames.size(); // Vị trí cuối cùng sau khi thêm
            frames.add(page);
            return new Result(true, frame, replacedPage);
        }
    }

}
