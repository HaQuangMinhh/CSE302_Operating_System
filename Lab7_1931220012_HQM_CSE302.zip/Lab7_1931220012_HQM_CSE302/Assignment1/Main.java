public class Main {


    public static void main(String[] args) {
        
        int[] references = {7, 0, 1, 2, 0, 3, 0, 4, 2, 3, 0, 3, 2, 1, 2, 0, 1, 7, 0, 1};
        int frameNum = 3;

        // FIFO
        PageReplacementPolicy fifo = new FIFOPolicy(frameNum);
        int fifoFaults = simulatePolicy(fifo, references, "FIFO");

        // LRU
        PageReplacementPolicy lru = new LRUPolicy(frameNum);
        int lruFaults = simulatePolicy(lru, references, "LRU");

        // OPT
        PageReplacementPolicy opt = new OPTPolicy(frameNum, references);
        int optFaults = simulatePolicy(opt, references, "Optimal");

        // In kết quả
        System.out.println("FIFO policy: " + fifoFaults + " page faults");
        System.out.println("LRU policy: " + lruFaults + " page faults");
        System.out.println("Optimal policy: " + optFaults + " page faults");

    }

    private static int simulatePolicy(PageReplacementPolicy policy, int[] references, String policyName) {
        int pageFaults = 0;
        System.out.println("\nSimulating " + policyName + " Policy:");
        
        System.out.println("Page Reference String: " + java.util.Arrays.toString(references));
        
        for (int i = 0; i < references.length; i++) {
        
            Result res = policy.refer(references[i]);
            if (res.isPageFault()) {
                pageFaults++;
                if (res.getRelpacedPage() != -1) {
                    System.out.printf("Page %d caused a fault, replaced page %d at frame %d%n", 
                        references[i], res.getRelpacedPage(), res.getFrame());
                } else {
                    System.out.printf("Page %d caused a fault, assigned to frame %d%n", 
                        references[i], res.getFrame());
                }
            }
        }
        return pageFaults;
    }


}
