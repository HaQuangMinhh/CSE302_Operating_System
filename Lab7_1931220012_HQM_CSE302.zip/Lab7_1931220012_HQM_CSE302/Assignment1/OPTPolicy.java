import java.util.LinkedList;

public class OPTPolicy implements PageReplacementPolicy {

    private int frameNum;
    private int[] references;
    private int currentIndex; // Theo dõi vị trí hiện tại trong references
    private LinkedList<Integer> frames;

    public OPTPolicy(int frameNum, int[] references) {
        this.frameNum = frameNum;
        this.references = references;
        this.currentIndex = 0;
        this.frames = new LinkedList<>();
    }

    @Override
    public Result refer(int page) {
        if (frames.contains(page)) {
            currentIndex++;
            return new Result(false, frames.indexOf(page), -1);
        }

        if (frames.size() < frameNum) {
            frames.add(page);
            currentIndex++;
            return new Result(true, frames.size() - 1, -1);
        } else {
            // Tìm trang sẽ không được dùng trong tương lai lâu nhất
            int farthest = -1;
            int replacedPage = -1;
            int frameToReplace = -1;

            for (int i = 0; i < frames.size(); i++) {
                int framePage = frames.get(i);
                int nextUse = findNextUse(framePage);
                if (nextUse == -1) { // Không dùng nữa trong tương lai
                    replacedPage = framePage;
                    frameToReplace = i;
                    break;
                } else if (nextUse > farthest) {
                    farthest = nextUse;
                    replacedPage = framePage;
                    frameToReplace = i;
                }
            }

            frames.set(frameToReplace, page);
            currentIndex++;
            return new Result(true, frameToReplace, replacedPage);
        }
    }

    private int findNextUse(int page) {
        for (int i = currentIndex; i < references.length; i++) {
            if (references[i] == page) {
                return i;
            }
        }
        return -1; // Không xuất hiện nữa
    }

}
