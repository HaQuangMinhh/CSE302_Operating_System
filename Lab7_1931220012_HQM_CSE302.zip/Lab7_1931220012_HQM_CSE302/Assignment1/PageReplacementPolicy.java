public interface PageReplacementPolicy {

    public Result refer ( int page );

    
}
