public class Result {

    private boolean pageFault ; 
    private int frame ; 
    private int replacedPage ; 
    
    public Result(boolean pageFault, int frame, int replacedPage ) {
        this.pageFault = pageFault;
        this.frame = frame;
        this.replacedPage = replacedPage ; 
    }
    public int getFrame() {
        return frame;
    }
    public void setFrame(int frame) {
        this.frame = frame;
    }
    public boolean isPageFault() {
        return pageFault;
    }
    public void setPageFault (boolean pageFault) {
        this.pageFault = pageFault;
    }
    public int getRelpacedPage () {
        return replacedPage;
    }
    public void setRelpacedPage (int replacedPage) {
        this.replacedPage = replacedPage;
    }

    
    @Override
    public String toString() {
        return "Result [pageFault=" + pageFault + ", frame=" + frame + ", repacedPage=" + replacedPage + "]";
    } 

}
