import java.util.LinkedList;

public class FIFOPolicy implements ReplacementPolicy {

    private int entryNum;
    private int[] values;
    private LinkedList<Integer> positionQueue = new LinkedList<>();

    public FIFOPolicy(int entryNum) {
        this.entryNum = entryNum;
        this.values = new int[this.entryNum];

        for (int i = 0; i < this.entryNum; i++) {
            this.values[i] = -1;
        }

        for (int i = 0; i < this.entryNum; i++) {
            this.positionQueue.addLast(i);
        }
    }

    @Override
    public ReplacementPolicy.Result refer(int value) {

        Result result;
        for (int i = 0; i < this.entryNum; i++) {
            if (this.values[i] == value) {
                result = new Result(true, value, i, -1);
                return result;
            }
        }

        int replacedPosition = this.positionQueue.removeFirst();
        int replacedValue = this.values[replacedPosition];
        this.values[replacedPosition] = value;

        this.positionQueue.addLast(replacedPosition);

        result = new Result(false, value, replacedPosition, replacedValue);
        return result;
    }

    @Override
    public void remove(int value) {

        for (int i = 0; i < this.entryNum; i++) {
            if (this.values[i] == value) {
                this.values[i] = -1;
                this.positionQueue.remove(i);
                this.positionQueue.addFirst(i);
                return;
            }
        }
    }
}
