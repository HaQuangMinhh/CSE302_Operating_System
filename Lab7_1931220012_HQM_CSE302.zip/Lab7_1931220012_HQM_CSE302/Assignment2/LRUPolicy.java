import java.util.LinkedHashMap;
import java.util.Map;

public class LRUPolicy implements ReplacementPolicy {

    private int capacity;
    private LinkedHashMap<Integer, Integer> map;

    public LRUPolicy(int capacity) {
        this.capacity = capacity;
        this.map = new LinkedHashMap<>(capacity, 0.75f, true) {
            protected boolean removeEldestEntry(Map.Entry<Integer, Integer> eldest) {
                return size() > capacity;
            }
        };
    }

    @Override
    public Result refer(int value) {
        if (map.containsKey(value)) {
            int pos = map.get(value);
            map.put(value, pos); // Cập nhật truy cập gần nhất
            return new Result(true, value, pos, -1);
        }
        int pos = map.size();
        if (pos >= capacity) {
            Map.Entry<Integer, Integer> eldest = map.entrySet().iterator().next();
            map.remove(eldest.getKey());
            pos = eldest.getValue();
        }
        map.put(value, pos);
        return new Result(false, value, pos, -1);
    }

    @Override
    public void remove(int value) {
        map.remove(value);
    }
}
