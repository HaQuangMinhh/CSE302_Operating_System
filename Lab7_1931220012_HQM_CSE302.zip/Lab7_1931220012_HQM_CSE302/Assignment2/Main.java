import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

public class Main {


    public static void main(String[] args) throws IOException {
        
        String backingFileName = "BACKING_STORE.bin" ; 
        int pageSize = 256 ; 
        int pageNum = 256 ; 
        int frameNum = 32 ; 
        int tlbEntryNum = 16 ; 

        BufferedReader addressReader = null ;

        try {
            VirtualMemoryManger vmm = new VirtualMemoryManger(pageSize , pageNum , tlbEntryNum , frameNum , "FIFO" , backingFileName );
            
            byte[] backingStore = Files.readAllBytes(Paths.get(backingFileName) );

            addressReader = new BufferedReader( new FileReader("addresses.txt"));
            
            String line = addressReader.readLine(); 

            int lineCount = 1 ; 
            
            while( line != null ) {

                int logicalAddress = Integer.parseInt(line);

                System.out.println("Line " + lineCount + "" + logicalAddress );

                byte value = vmm.read(logicalAddress);
                if ( value != backingStore[logicalAddress] ) {
                    System.out.println("Line " + lineCount + " - " + logicalAddress +": read value " + value + ", expected: " + backingStore[logicalAddress] );
                }

                line = addressReader.readLine();
                lineCount++;
            }

            System.out.println("DONE");
            System.out.println("TLB Miss count: " + vmm.getTlbMissCount());
            System.out.println("Page fault count: " + vmm.getPageFaultCount());
        } finally {
            if ( addressReader != null ) {
                addressReader.close();
            }
        }


    }

}
