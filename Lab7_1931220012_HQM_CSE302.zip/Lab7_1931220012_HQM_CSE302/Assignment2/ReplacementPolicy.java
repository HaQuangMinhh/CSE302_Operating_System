public interface ReplacementPolicy {

    public Result refer ( int value ) ;
    public void remove ( int value ) ;

    public class Result {

        private boolean found ; 
        private int page ; 
        private int position ; 
        private int replacedValue ;
        
        
        public Result(boolean found, int page, int position, int replacedValue) {
            this.found = found;
            this.page = page;
            this.position = position;
            this.replacedValue = replacedValue;
        }


        public boolean isFound() {
            return found;
        }


        public int getPage() {
            return page;
        }


        public int getPosition() {
            return position;
        }


        public int getReplacedValue() {
            return replacedValue;
        } 

        
    }
}
