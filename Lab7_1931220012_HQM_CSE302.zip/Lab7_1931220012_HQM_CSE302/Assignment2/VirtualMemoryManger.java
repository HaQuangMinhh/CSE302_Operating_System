import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.Queue;

import javax.imageio.IIOException;

public class VirtualMemoryManger {

    private int pageSize;
    private TLB tlb;
    private PageTable pageTable;
    private PhysicalMemory physicalMemory;
    private BackingStore backingStore;
    
    private int tlbMissCount = 0 ; 
    private int pageFaultCount = 0 ; 

    public VirtualMemoryManger(int pageSize, int pageNum, int tlbEntryNum, int frameNum, String policyName,
            String backingStoreFileName) throws IOException { 
        this.pageSize = pageSize;
        this.tlb = new TLB(tlbEntryNum, policyName);
        this.pageTable = new PageTable(pageNum);
        this.physicalMemory = new PhysicalMemory(pageSize, frameNum, policyName);
        this.backingStore = new BackingStore(pageSize, pageNum, backingStoreFileName);
    }

    public byte read(int logicalAddress) {
        int page = logicalAddress / this.pageSize;
        int offset = logicalAddress % this.pageSize;

        Integer frame = tlb.lookup(page);
        if (frame == null) {
            tlbMissCount++;
            frame = pageTable.lookup(page);
            if (frame == null) {
                pageFaultCount++;
                frame = physicalMemory.loadPage(page, backingStore);
                pageTable.update(page, frame);
            }
            tlb.update(page, frame);
        }
        return physicalMemory.read(frame, offset);
    }

    public int getTlbMissCount() {
        return tlbMissCount;
    }

    public int getPageFaultCount() {
        return pageFaultCount;
    }



}

class TLB {
    private LinkedHashMap<Integer, Integer> cache;
    private int capacity;

    public TLB(int capacity, String policyName) {
        this.capacity = capacity;
        this.cache = new LinkedHashMap<>(capacity, 0.75f, true) {
            protected boolean removeEldestEntry(Map.Entry<Integer, Integer> eldest) {
                return size() > capacity; // LRU tự động khi vượt capacity
            }
        };
    }

    public Integer lookup(int pageNumber) {
        return cache.get(pageNumber);
    }

    public void update(int pageNumber, int frameNumber) {
        cache.put(pageNumber, frameNumber);
    }
}



class PageTable {
    
    private int pageNum;
    private int[] frames;

    public PageTable(int pageNum) {
        this.pageNum = pageNum;
        this.frames = new int[this.pageNum];
        for (int i = 0; i < this.pageNum; i++) {
            this.frames[i] = -1; // -1 nghĩa là chưa có frame
        }
    }

    public Integer lookup(int pageNumber) {
        if (frames[pageNumber] == -1) return null;
        return frames[pageNumber];
    }

    public void update(int pageNumber, int frameNumber) {
        frames[pageNumber] = frameNumber;
    }
}

class PhysicalMemory {

    private int frameSize;
    private int frameNum;
    private byte[] memory;
    private ReplacementPolicy replacePolicy;

    public PhysicalMemory(int frameSize, int frameNum, String policyName) {
        this.frameSize = frameSize;
        this.frameNum = frameNum;
        this.memory = new byte[this.frameSize * this.frameNum];
        if (policyName.trim().equalsIgnoreCase("FIFO")) {
            this.replacePolicy = new FIFOPolicy(frameNum);
        } else if (policyName.trim().equalsIgnoreCase("LRU")) {
            this.replacePolicy = new LRUPolicy(frameNum);
        } else {
            throw new IllegalArgumentException("Invalid policy: " + policyName);
        }
    }

    public byte read(int frame, int offset) {
        return memory[frame * frameSize + offset];
    }

    public int loadPage(int page, BackingStore backingStore) {
        byte[] pageData = backingStore.readPage(page);
        ReplacementPolicy.Result result = replacePolicy.refer(page);
        int frame = result.getPosition();
        // Copy dữ liệu từ backing store vào frame
        System.arraycopy(pageData, 0, memory, frame * frameSize, frameSize);
        return frame;
    }

}

class BackingStore {

    private int pageSize;
    private int pageNum;
    private RandomAccessFile backingFile;

    public BackingStore(int pageSize, int pageNum, String backingFileName) throws IOException {
        this.pageSize = pageSize;
        this.pageNum = pageNum;
        this.backingFile = new RandomAccessFile(backingFileName, "r");
        if (this.backingFile.length() != this.pageSize * this.pageNum) {
            throw new IllegalArgumentException("Backing file: " + backingFileName + ": invalid size");
        }
    }

    public byte[] readPage(int pageNumber) {
        byte[] pageData = new byte[pageSize];
        try {
            backingFile.seek(pageNumber * pageSize);
            backingFile.readFully(pageData);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return pageData;
    }
}
