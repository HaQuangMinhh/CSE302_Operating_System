
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class B1_H2O {

    private int H = 0;
    private int O = 0;

    private Lock lock = new ReentrantLock();
    private Condition conditionH = this.lock.newCondition();
    private Condition conditionO = this.lock.newCondition();

    private boolean fairness;

    // public H2O(boolean fairness) {
    //     this.fairness = fairness;
    // }
    public void hydro() throws InterruptedException {
        lock.lock();
        try {
            H++;
            if (H >= 2 && O >= 1) {
                this.conditionH.signal();
                this.conditionO.signal();
                this.H = H - 2;
                this.O = O - 1;
                System.out.println("H2O");
            } else {
                this.conditionH.await();
            }
        } finally {
            lock.unlock();
        }
    }

    public void oxy() throws InterruptedException {
        lock.lock();
        try {
            O++;
            if (H >= 2 && O >= 1) {
                this.conditionH.signal();
                this.conditionH.signal();
                this.H = H - 2;
                this.O = O - 1;

                System.out.println("H2O");
            } else {
                this.conditionO.await();
            }
        } finally {
            lock.unlock();
        }
    }

    public int getH() {
        return H;
    }

    public int getO() {
        return O;
    }

}
