
public class B1_Main {

    public static void main(String[] args) throws Exception {
        B1_H2O h2o = new B1_H2O();
        

        for (int i = 0; i < 5; i++) {
            Thread h1=new HydroThread(h2o);
            h1.start();
            Thread h2=new HydroThread(h2o);
            h2.start();
            Thread o1=new OxyThread(h2o);
            o1.start();
        }
    }
}

class HydroThread extends Thread {

    private final B1_H2O h2o;

    public HydroThread(B1_H2O h2o) {
        this.h2o = h2o;
    }

    @Override
    public void run() {
        try {
            h2o.hydro();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}

class OxyThread extends Thread {

    private B1_H2O h2o;

    public OxyThread(B1_H2O h2o) {
        this.h2o = h2o;
    }

    public void run() {
        try {
            h2o.oxy();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }
}
