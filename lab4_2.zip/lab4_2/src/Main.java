import java.util.Random;

public class Main {

    public static void main(String[] args) throws InterruptedException {
        MyThreadPool tp = new MyThreadPool(5);

        for (int i = 0; i < 100; i++) {
            Task task = new Task(i);
            tp.add(task);
        }
        tp.shutdown();
    }

}

class Task implements Runnable {

    private int index;

    public Task(int index) {
        this.index = index;
    }

    @Override
    public void run() {
        Random rd = new Random();
        try {
            Thread.sleep(rd.nextInt(100));
        } catch (Exception e) {
        }
        System.out.println("Task " + this.index + " finished");
    }

}
